/*
 * LCD_config.h
 * Created: 4/26/2024 7:34:08 PM
 *  Author: thesuperstar3babsy
 */ 


#ifndef LCD_CONFIG_H_
#define LCD_CONFIG_H_

#define eight_bits_mode
//#define four_bits_mode

#endif /* LCD_CONFIG_H_ */